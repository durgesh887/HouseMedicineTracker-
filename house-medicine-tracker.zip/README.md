# HouseMedicineTracker

Starter full-stack repo: React + Vite + Tailwind frontend, Node + Express backend with SQLite and a Tesseract.js OCR endpoint.

This is a minimal, opinionated starter to implement the UI/UX spec. Use it as a foundation and extend features (auth, push notifications, tests, deployment) as needed.

## Quick start (dev)

### Backend
```bash
cd backend
npm install
# create data folder
node src/init_db.js
node src/index.js
```

Backend runs on port 4000 by default.

### Frontend
```bash
cd frontend
npm install
npm run dev
```

Frontend runs on port 5173 by default (Vite).

## Notes
- OCR endpoint uses Tesseract.js. For better accuracy consider Google Cloud Vision (switch in `backend/src/routes/scan.js`).
- SQLite DB file: `backend/data/medicines.db`
- Environment variables example: `.env.example` in the repo root.

