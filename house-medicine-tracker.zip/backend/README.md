Backend for HouseMedicineTracker

- Node + Express
- SQLite (file in backend/data)
- Tesseract.js OCR endpoint at POST /api/scan (multipart form-data, field name 'image')

Example curl to test OCR:
curl -F "image=@/path/to/photo.jpg" http://localhost:4000/api/scan
