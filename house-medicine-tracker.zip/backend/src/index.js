const express = require('express');
const cors = require('cors');
const path = require('path');
const medicinesRouter = require('./routes/medicines');
const scanRouter = require('./routes/scan');
require('dotenv').config();

const app = express();
app.use(cors());
app.use(express.json());

app.use('/api/medicines', medicinesRouter);
app.use('/api/scan', scanRouter);

const PORT = process.env.PORT || 4000;
app.listen(PORT, ()=> console.log(`HouseMedicineTracker backend running on ${PORT}`));
