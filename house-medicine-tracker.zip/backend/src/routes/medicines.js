const express = require('express');
const router = express.Router();
const db = require('../db');

// List all medicines (with optional filter)
router.get('/', (req, res)=>{
  const q = req.query.filter;
  let sql = 'SELECT m.*, p.name as person_name FROM medicines m LEFT JOIN persons p ON m.person_id = p.id ORDER BY expiry_date ASC';
  db.all(sql, [], (err, rows)=>{
    if(err) return res.status(500).json({error: err.message});
    res.json(rows);
  });
});

router.post('/', (req, res)=>{
  const {name, dosage, quantity, expiry_date, person_id, verified, notes} = req.body;
  const sql = `INSERT INTO medicines (name,dosage,quantity,expiry_date,person_id,verified,notes) VALUES (?,?,?,?,?,?,?)`;
  db.run(sql, [name,dosage,quantity,expiry_date,person_id || null, verified?1:0, notes||''], function(err){
    if(err) return res.status(500).json({error: err.message});
    res.json({id: this.lastID});
  });
});

router.get('/:id', (req, res)=>{
  const id = req.params.id;
  db.get('SELECT * FROM medicines WHERE id = ?', [id], (err,row)=>{
    if(err) return res.status(500).json({error: err.message});
    if(!row) return res.status(404).json({error: 'Not found'});
    res.json(row);
  });
});

router.put('/:id', (req, res)=>{
  const id = req.params.id;
  const {name, dosage, quantity, expiry_date, person_id, verified, notes} = req.body;
  const sql = `UPDATE medicines SET name=?,dosage=?,quantity=?,expiry_date=?,person_id=?,verified=?,notes=? WHERE id=?`;
  db.run(sql, [name,dosage,quantity,expiry_date,person_id || null, verified?1:0, notes||'', id], function(err){
    if(err) return res.status(500).json({error: err.message});
    res.json({changes: this.changes});
  });
});

router.delete('/:id', (req, res)=>{
  const id = req.params.id;
  db.run('DELETE FROM medicines WHERE id = ?', [id], function(err){
    if(err) return res.status(500).json({error: err.message});
    res.json({deleted: this.changes});
  });
});

module.exports = router;
