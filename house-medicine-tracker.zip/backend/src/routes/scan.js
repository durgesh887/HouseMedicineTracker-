const express = require('express');
const router = express.Router();
const multer = require('multer');
const { createWorker } = require('tesseract.js');
const upload = multer({ dest: 'tmp/' });
const fs = require('fs');

// OCR scan endpoint - accepts image file upload (multipart/form-data)
router.post('/', upload.single('image'), async (req, res)=>{
  if(!req.file) return res.status(400).json({error: 'No image uploaded'});
  const imagePath = req.file.path;

  const worker = createWorker({
    logger: m => {} // suppress logs
  });
  try{
    await worker.load();
    await worker.loadLanguage('eng');
    await worker.initialize('eng');
    const { data: { text } } = await worker.recognize(imagePath);
    await worker.terminate();
    // crude expiry date parse: find first yyyy or dd/mm like token (improvable)
    const lines = text.split(/\n|\r/).map(s=>s.trim()).filter(Boolean);
    // simple regex for dates (dd/mm/yyyy or yyyy-mm-dd)
    const dateRegex = /(\d{2}[\/\-]\d{2}[\/\-]\d{2,4})|(\d{4}[\-]\d{2}[\-]\d{2})/;
    let found = null;
    for(const l of lines){
      const m = l.match(dateRegex);
      if(m){ found = m[0]; break; }
    }
    res.json({text, parsed_expiry: found || null, lines});
  }catch(err){
    console.error(err);
    res.status(500).json({error: 'OCR failed', details: err.message});
  }finally{
    // remove temp file
    try{ fs.unlinkSync(imagePath);}catch(e){}
  }
});

module.exports = router;
