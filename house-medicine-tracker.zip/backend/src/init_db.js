const fs = require('fs');
const path = require('path');
const dbFile = path.join(__dirname, '..', 'data', 'medicines.db');
if (!fs.existsSync(path.dirname(dbFile))) fs.mkdirSync(path.dirname(dbFile), {recursive:true});
const sqlite3 = require('sqlite3').verbose();
const db = new sqlite3.Database(dbFile);

db.serialize(()=>{
  db.run(`
    CREATE TABLE IF NOT EXISTS persons (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT,
      relation TEXT,
      avatar TEXT
    );
  `);
  db.run(`
    CREATE TABLE IF NOT EXISTS medicines (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT,
      dosage TEXT,
      quantity INTEGER,
      expiry_date TEXT,
      person_id INTEGER,
      verified INTEGER DEFAULT 0,
      notes TEXT,
      created_at TEXT DEFAULT (datetime('now')),
      FOREIGN KEY(person_id) REFERENCES persons(id)
    );
  `);
  console.log('Initialized DB at', dbFile);
  db.close();
});
