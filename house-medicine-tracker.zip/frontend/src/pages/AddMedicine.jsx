import React, {useState} from 'react'
import axios from 'axios'
import { useNavigate, Link } from 'react-router-dom'

export default function AddMedicine(){
  const [form, setForm] = useState({name:'',dosage:'',quantity:1,expiry_date:'',person_id:null,verified:false,notes:''})
  const navigate = useNavigate()

  const submit = async (e)=>{
    e.preventDefault()
    try{
      await axios.post('http://localhost:4000/api/medicines', form)
      navigate('/inventory')
    }catch(err){
      alert('Failed to save.')
    }
  }

  return (
    <div className='container'>
      <div className='header'>
        <h2>Add Medicine</h2>
        <Link to='/' className='small'>Home</Link>
      </div>
      <form onSubmit={submit} className='card'>
        <label className='small'>Name</label>
        <input required value={form.name} onChange={e=>setForm({...form,name:e.target.value})} style={{width:'100%',padding:10,borderRadius:10,marginBottom:8}} />

        <label className='small'>Dosage</label>
        <input value={form.dosage} onChange={e=>setForm({...form,dosage:e.target.value})} style={{width:'100%',padding:10,borderRadius:10,marginBottom:8}} />

        <label className='small'>Quantity</label>
        <input type='number' value={form.quantity} onChange={e=>setForm({...form,quantity:parseInt(e.target.value||0)})} style={{width:'100%',padding:10,borderRadius:10,marginBottom:8}} />

        <label className='small'>Expiry Date</label>
        <input placeholder='YYYY-MM-DD' value={form.expiry_date} onChange={e=>setForm({...form,expiry_date:e.target.value})} style={{width:'100%',padding:10,borderRadius:10,marginBottom:8}} />

        <label className='small'><input type='checkbox' checked={form.verified} onChange={e=>setForm({...form,verified:e.target.checked})} /> Verified</label>

        <div style={{marginTop:12}}>
          <button className='btn' type='submit'>Save</button>
        </div>
      </form>
    </div>
  )
}
