import React, {useEffect, useState} from 'react'
import axios from 'axios'
import { Link } from 'react-router-dom'

export default function Inventory(){
  const [list,setList] = useState([])
  useEffect(()=>{
    axios.get('http://localhost:4000/api/medicines').then(r=> setList(r.data)).catch(()=>{})
  },[])
  return (
    <div className='container'>
      <div className='header'>
        <h2>Inventory</h2>
        <Link to='/' className='small'>Home</Link>
      </div>
      <div className='card'>
        <input placeholder='Search medicines' style={{width:'100%',padding:10,borderRadius:10,border:'1px solid #eef2f5'}} />
      </div>
      <div className='card'>
        {list.length===0 ? <p className='small'>No medicines yet.</p> : (
          <ul>
            {list.map(m=> (
              <li key={m.id} className='list-item'>
                <div>
                  <div style={{fontWeight:600}}>{m.name}</div>
                  <div className='small'>Expires: {m.expiry_date || 'N/A'}</div>
                </div>
                <div style={{textAlign:'right'}}>
                  <div className='small'>Qty: {m.quantity}</div>
                </div>
              </li>
            ))}
          </ul>
        )}
      </div>
    </div>
  )
}
