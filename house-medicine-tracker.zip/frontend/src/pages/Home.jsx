import React, {useEffect, useState} from 'react'
import { Link } from 'react-router-dom'
import axios from 'axios'

export default function Home(){
  const [todayList, setTodayList] = useState([])

  useEffect(()=>{
    // fetch medicines (simple)
    axios.get('http://localhost:4000/api/medicines').then(r=> setTodayList(r.data)).catch(()=>{})
  },[])

  return (
    <div className='container'>
      <div className='header'>
        <h1>HouseMedicineTracker</h1>
        <Link to='/inventory' className='small'>Inventory</Link>
      </div>

      <div className='card'>
        <h3>Today's Reminders</h3>
        {todayList.length===0 ? <p className='small'>No reminders for today. Add medicines to get started.</p> : (
          <ul>
            {todayList.map(m=> (
              <li key={m.id} className='list-item'>
                <div>
                  <div style={{fontWeight:600}}>{m.name} <span className='small'>• {m.dosage}</span></div>
                  <div className='small'>Expires: {m.expiry_date || 'N/A'}</div>
                </div>
                <div style={{textAlign:'right'}}>
                  <div>{m.quantity}</div>
                </div>
              </li>
            ))}
          </ul>
        )}
      </div>

      <div className='card'>
        <h3>Quick Actions</h3>
        <div style={{display:'flex', gap:8}}>
          <Link className='btn' to='/add'>Add Medicine</Link>
          <a className='btn' href='/' onClick={(e)=>{e.preventDefault(); alert('Export not implemented in starter.')}}>Export CSV</a>
        </div>
      </div>

      <div className='fab' title='Add'>+</div>
    </div>
  )
}
