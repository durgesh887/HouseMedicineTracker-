Frontend (Vite + React + Tailwind) starter.

Install and run:
cd frontend
npm install
npm run dev
